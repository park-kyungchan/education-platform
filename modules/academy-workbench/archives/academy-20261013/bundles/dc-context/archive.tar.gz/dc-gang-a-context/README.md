# dc-gang-a recovered academy context

78 source-anchored operational facts survived the workspace loss and are preserved here. This is a regenerated wrapper, source index, and typed evidence graph, not a byte-identical restoration of the earlier 14 files. The source archive separately preserves exact original code and PR discussion data.

The graph organizes repository → domains/actors/source files → facts. Edges describe containment, historical actor roles, and evidence; they never grant permission. Original rules are historical source contracts and yield to the latest user corrections. The original 107-node/47-edge graph is not claimed as recovered.

Coverage is bounded to current remote main, three accessible branches, and 102 reachable commits. Three fonts, outside-Git originals, native successor equivalence and exact Git custody remain unresolved. Do not delete the original repositories on the strength of this package.

Run python validate_context.py for schema, source-anchor, graph and inventory checks. No original application code is executed.
