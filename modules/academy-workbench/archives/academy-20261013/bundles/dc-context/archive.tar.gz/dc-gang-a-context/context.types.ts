/** Inert historical data contracts. They provide no execution or account authority. */
export type RepositoryId = "park-kyungchan/dc-gang-a";
export type ClaimClass = "historical_record" | "repository_source_contract" | "acceptance_limit";
export type Actor = "teacher" | "student" | "product" | "source";
export interface SourceRef {
  repository: RepositoryId;
  commit: string;
  path: string;
  blobSha: string;
  anchor: string | null;
  line: number | null;
  url: string;
}
export interface OperationalFact {
  id: `dc-gang-a:${string}`;
  domain: string;
  actor: Actor;
  statement: string;
  claimClass: ClaimClass;
  applicability: "snapshot_context_only_latest_user_corrections_take_precedence";
  grantsCurrentAuthority: false;
  sources: SourceRef[];
}
export interface ContextDocument {
  schemaVersion: 1;
  repository: RepositoryId;
  snapshotCommit: string;
  authority: "historical_source_data_only_latest_user_corrections_precede";
  recovery: string;
  facts: OperationalFact[];
}
export type NodeType = "repository" | "domain" | "actor" | "source" | "fact";
export interface ContextNode {
  id: string;
  type: NodeType;
  label: string;
  parent?: string;
  semantics?: "role_in_historical_source_not_new_permission";
  source?: SourceRef;
  factId?: OperationalFact["id"];
}
export interface ContextEdge {
  from: string;
  to: string;
  type: "contains" | "role_in_source" | "supports_historical_claim";
}
export interface ContextTopology {
  schemaVersion: 1;
  recovery: string;
  edgeDirection: "predecessor_to_dependent";
  nodes: ContextNode[];
  edges: ContextEdge[];
  topologicalLayers: string[][];
}
export type ArchiveDisposition = "byte_exact_private_archive" | "binary_gap";
export interface SnapshotFile {
  path: string;
  mode: string;
  type: "blob";
  sha: string;
  size: number;
  url: string;
  archiveDisposition: ArchiveDisposition;
}
export type SourceRelationType = "current_remote" | "archived_native" | "unresolved_successor" | "source_historical_claim";
