from pathlib import Path
import json,hashlib
import jsonschema
ROOT=Path(__file__).resolve().parent
def read(p):return json.loads((ROOT/p).read_text())
ctx=read('operational-context.json');graph=read('operational-topology.json');inv=read('source-inventory.json')
jsonschema.validate(ctx,read('operational-context.schema.json'))
errors=[];files={x['path']:x for x in inv['mainFiles']};facts=ctx['facts'];ids=[f['id'] for f in facts]
if len(ids)!=len(set(ids)):errors.append('duplicate fact ids')
for f in facts:
 for s in f['sources']:
  x=files.get(s['path'])
  if x is None or x['sha']!=s['blobSha'] or s['commit']!=ctx['snapshotCommit']:errors.append('source mismatch: '+f['id'])
  p=ROOT.parent/'frozen-source'/'objects'/s['blobSha']
  if p.is_file():
   b=p.read_bytes()
   if hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()!=s['blobSha']:errors.append('invalid source object: '+f['id'])
   if s['line'] is not None and not 1<=s['line']<=len(b.decode().splitlines()):errors.append('source line out of range: '+f['id'])
nodes={x['id']:x for x in graph['nodes']}
if len(nodes)!=len(graph['nodes']):errors.append('duplicate graph nodes')
level={node:i for i,layer in enumerate(graph['topologicalLayers']) for node in layer}
if set(level)!=set(nodes):errors.append('incomplete topological layers')
for e in graph['edges']:
 if e['from'] not in nodes or e['to'] not in nodes:errors.append('dangling graph edge')
 elif level[e['from']]>=level[e['to']]:errors.append('non-topological graph edge')
result={'schemaVersion':1,'status':'pass' if not errors else 'fail','facts':len(facts),'nodes':len(nodes),'edges':len(graph['edges']),'sourceFiles':len(files),'errors':errors,'sourceApplicationTests':'not_run_read_only_extraction','typescriptValidation':'syntax_transpile_only_not_full_typecheck'}
(ROOT/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
raise SystemExit(bool(errors))
