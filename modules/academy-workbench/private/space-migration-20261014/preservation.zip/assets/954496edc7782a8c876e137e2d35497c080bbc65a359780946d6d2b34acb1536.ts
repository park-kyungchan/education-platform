/** TypeScript/Bun append adapter. Reads only the sanitized capture contract.
 * Never reads, uploads, evaluates, or fetches the raw HAR.
 * bun append-imported-capture-1.5.0.ts --out-dir ./generated
 */
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
type Json=Record<string,any>;
const clone=<T>(x:T):T=>JSON.parse(JSON.stringify(x));
const sha=(x:string|Buffer)=>createHash('sha256').update(x).digest('hex');
const stable=(x:any):any=>Array.isArray(x)?x.map(stable):x!==null&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])])):x;
const sourceMessageId='Sentinel_349165f4126c8191a77223db78a6d505',uploadReportedAt='2026-10-07T08:05:53.898571+00:00';
const captureAt='2026-10-07T08:05:31.277Z',recordedAt='2026-10-07T08:25:48Z';
const rawSha='b8c7dfc95ecc5b6808f5a3db56d6552b0ebfac87d37906b29fb6b4a6eb86607f',rawRef='libfile_8b1253b790148191914e504c938ffc5e';
const sanitizedSha='e177dfcb1f3d1c395f65e58076dc32d12b47162070874c1779ca5fcffe44bc7d';
const baseReference='library-file:fde1_bGliZmlsZV9HbXBWV1E2YzJQeEVmT3lFZEthTnRB_FileDrive_73e3d24e44d881918a9b9622fd5a4193';
function infer(x:any):any{
 if(Array.isArray(x)){if(!x.length)return {type:'array'};const ss:any[]=[];for(const y of x){const s=infer(y);if(!ss.some(q=>JSON.stringify(q)===JSON.stringify(s)))ss.push(s);}return {type:'array',items:ss.length===1?ss[0]:{anyOf:ss}};}
 if(x===null)return {type:['string','number','object','array','null']};
 if(typeof x==='object')return {type:'object',required:Object.keys(x),properties:Object.fromEntries(Object.entries(x).map(([k,v])=>[k,infer(v)])),additionalProperties:false};
 return {type:typeof x==='boolean'?'boolean':typeof x==='number'?'integer':'string'};
}
export function appendImportedCapture(old:Json,oldBytes:string,oldSchema:Json,safe:Json,safeBytes:string){
 assert.equal(old.version,'1.4.0');assert.equal(sha(safeBytes),sanitizedSha);assert.equal(safe.rawSha256,rawSha);assert.equal(safe.libraryFileId,rawRef);assert.equal(safe.captureTimestamp,captureAt);
 assert.equal(safe.liveServerFetch,false);assert.equal(safe.authenticatedResponseIndependentlyVerified,false);assert.equal(safe.staticStructureVerified,true);
 assert.equal(safe.scope.dataRows,27);assert.equal(safe.scope.exactTargetNameRows,27);assert.equal(safe.scope.mismatchRows,0);assert.equal(safe.scope.otherStudentRows,0);assert.equal(safe.scope.periodValue,'3');assert.equal(safe.scope.replaceExisting44RowSnapshot,false);
 const studentId=old.student.canonical_snapshot_student_key,p=clone(old);
 p.$schema='이루한_숙제제출_교사확인계획_1.5.0.schema.json';p.version='1.5.0';p.revised_at_utc=recordedAt;p.previous_revision={version:'1.4.0',file_name:'이루한_숙제제출_교사확인계획_1.4.0.json',sha256:sha(oldBytes)};
 p.source_messages.push({message_id:sourceMessageId,actor:'user',sent_at_utc:uploadReportedAt,purpose:'provided_uploaded_capture_in_response_to_existing_request',message_text_supplied:false});
 const targets=[{code:'1N870P',entityId:'record:1N87:6:1N870P',oldDecisionId:'decision:ruhan:20261007:gauss6-submission:pending-v1',newDecisionId:'decision:ruhan:20261007:gauss6-submission:pending-v2'},{code:'1MHL0J',entityId:'scope:ruhan:20261002:davinci:unit2_TEST',oldDecisionId:'decision:ruhan:20261007:davinci2-TEST-submission:pending-v1',newDecisionId:'decision:ruhan:20261007:davinci2-TEST-submission:pending-v2'}];
 const claims=targets.map(t=>{
  const item=safe.requestedItems.find((x:Json)=>x.nativeCode===t.code);assert(item);assert.equal(item.nativeCodeLiteralMatches,0);assert.equal(item.matchingLabelRows,0);assert.equal(item.status,'uploaded_recent3w_scope_absent');assert.equal(item.score,null);assert.equal(item.attemptedAt,null);
  const value={nativeCode:item.nativeCode,bookCode:item.bookCode,targetLabel:item.label,status:'not_observed_within_recent3w_capture',nativeCodeLiteralMatches:0,matchingLabelRows:0,sourceCapture:'user_uploaded_HAR',collector:'assistant_static_parser',captureTimestampSemantics:'timestamp_recorded_in_uploaded_HAR_entry',staticScopeVerified:true,verificationLevel:'structural_scope_verified',liveServerFetch:false,authenticatedResponseIndependentlyVerified:false,selectedStudentMatchesExpectedAllowlistedStudent:true,capturedResponseRows:27,exactTargetRows:27,mismatchRows:0,completeHistoricalSnapshot:false,replaceExisting44RowSnapshot:false,learningEventTimes:'unknown',score:null,attemptedAt:null,relatedDifferentTopicRows:item.relatedDifferentTopicRows??0,relatedRowsAreTotalAssessment:false};
  const e:Json={sourceKind:'imported_snapshot',actor:{kind:'assistant',role:'source_collector',id:null},sourceRef:{sourceMessageId,reference:rawRef,sha256:rawSha,jsonPointer:null},reportedAt:uploadReportedAt,observedAt:captureAt,capturedAt:captureAt,recordedAt,timeRaw:'HAR capture timestamp',verificationStatus:'unverified',verificationDetail:'structural_scope_verified; authenticated_response_not_independently_verified; no_live_fetch',scope:{studentId,entityIds:[t.entityId],fields:['grading_registration_observation_in_uploaded_capture'],window:{from:null,to:null,labelRaw:'최근3주 (sort_date=3)'}},claim:{type:'not_observed_within_recent3w_capture',value},revision:1,supersedesEvidenceIds:[],retractsEvidenceIds:[],conflictingEvidenceIds:[]};
  e.evidenceId='evidence:ruhan:'+sha(JSON.stringify(stable({sourceRef:e.sourceRef,scope:e.scope,claim:e.claim}))).slice(0,24);return e;
 });
 const pending=targets.map((t,i)=>{const prior=old.decision_records.find((d:Json)=>d.decisionId===t.oldDecisionId);assert(prior);return {...clone(prior),decisionId:t.newDecisionId,evidenceIds:[...prior.evidenceIds,claims[i].evidenceId],decisionStatus:'pending',recordedAt};});
 p.evidence_records.push(...claims);p.decision_records.push(...pending);
 p.imported_capture_claims={sourceReference:rawRef,sourceSha256:rawSha,sanitizedContractSha256:sanitizedSha,captureTimestamp:captureAt,uploadMessageReportedAt:uploadReportedAt,evidenceIds:claims.map(x=>x.evidenceId),originalHARReuploaded:false,rawResponseRowsCopied:false,credentialsCopied:false,sourceKind:'imported_snapshot',liveServerFetch:false,authenticatedResponseIndependentlyVerified:false,final1830Judgment:'pending'};
 p.current_decision_refs={gauss6TotalSubmission:pending[0].decisionId,davinci2TotalSubmission:pending[1].decisionId};
 p.decision_revision_relations=targets.map((t,i)=>({currentDecisionId:pending[i].decisionId,supersedesDecisionId:t.oldDecisionId,reason:'new_uploaded_capture_evidence_appended_without_final_judgment',previousRecordModified:false}));
 for(const k of ['gauss_submission_check','davinci_total_assignment_comparison','davinci_assignment_scope','dayrecord_execution','teacher_solution_review','reminder_plan','terminology','homework_comparison_basis','scope_structure_revision_history','assignments','legacy_evidence_bindings','legacy_decision_bindings'])assert.deepEqual(p[k],old[k],k);
 assert.deepEqual(p.evidence_records.slice(0,old.evidence_records.length),old.evidence_records);assert.deepEqual(p.decision_records.slice(0,old.decision_records.length),old.decision_records);
 assert.equal(claims.length,2);assert(claims.every(e=>e.sourceKind==='imported_snapshot'&&e.verificationStatus==='unverified'&&!e.directObservationReceipt));assert(pending.every(d=>d.decisionStatus==='pending'));assert.equal(p.assignments[0].scopeItems.length,17);
 const minimal={type:'uploaded_capture_minimal_claims',sourceReference:rawRef,sourceSha256:rawSha,captureTimestamp:captureAt,uploadMessageReportedAt:uploadReportedAt,claims,evidenceContractVersion:'academy.evidence/1.1.0',final1830Judgment:'pending',liveServerFetch:false,authenticatedResponseIndependentlyVerified:false,rawHAROrRowsCopied:false};
 const schema=clone(oldSchema);schema.properties.version={const:'1.5.0'};schema.properties.source_messages=infer(p.source_messages);schema.properties.imported_capture_claims=infer(p.imported_capture_claims);schema.properties.current_decision_refs=infer(p.current_decision_refs);schema.properties.decision_revision_relations=infer(p.decision_revision_relations);schema.$defs.DecisionRecord.properties.decisionStatus.enum=['pending','confirmed','conflicted','superseded','retracted'];schema.$defs.EvidenceRecord.properties.statementProvenance.properties.sourceMessageId={type:'string',minLength:1,maxLength:512};
 const rev={type:'student_homework_review_plan_append_revision',plan_id:p.plan_id,revision_id:'revision_0005',from_version:'1.4.0',to_version:'1.5.0',recorded_at_utc:recordedAt,base:p.previous_revision,source_message_id:sourceMessageId,source_reported_at_utc:uploadReportedAt,events:[{kind:'minimal_uploaded_capture_evidence_appended',sourceSha256:rawSha,captureTimestamp:captureAt,newEvidenceIds:claims.map(e=>e.evidenceId),newDecisionIds:pending.map(d=>d.decisionId),sourceKind:'imported_snapshot',liveServerFetch:false,authenticatedResponseIndependentlyVerified:false,previousEvidenceModified:false,previousDecisionsModified:false,studentPerformanceChanged:false,assignment17Changed:false,finalJudgment:'pending'}]};
 return {plan:p,schema,revision:rev,minimal};
}
function cli(){
 const args=process.argv.slice(2),opt=(x:string)=>{const i=args.indexOf(x);return i<0?undefined:args[i+1];},base=resolve(opt('--base-dir')??dirname(fileURLToPath(import.meta.url))),outArg=opt('--out-dir');if(!outArg)throw Error('--out-dir required');const out=resolve(outArg),verify=opt('--verify-against')?resolve(opt('--verify-against')!):null;if(out===base||out===verify)throw Error('Separate output directory required.');
 const oldBytes=readFileSync(resolve(base,'assignment-1.4.0/이루한_숙제제출_교사확인계획_1.4.0.json'),'utf8'),safeBytes=readFileSync(resolve(base,'../academy_har_minimal_evidence.sanitized.json'),'utf8');
 const r=appendImportedCapture(JSON.parse(oldBytes),oldBytes,JSON.parse(readFileSync(resolve(base,'assignment-1.4.0/이루한_숙제제출_교사확인계획_1.4.0.schema.json'),'utf8')),JSON.parse(safeBytes),safeBytes);mkdirSync(out,{recursive:true});
 const files=[['이루한_숙제제출_교사확인계획_1.5.0.json',r.plan],['이루한_숙제제출_교사확인계획_1.5.0.schema.json',r.schema],['이루한_숙제제출_교사확인계획_revision_0005.json',r.revision],['이루한_업로드캡처_최소근거_1.0.0.json',r.minimal]] as const;
 const results=files.map(([name,value])=>{const text=JSON.stringify(value,null,2)+'\n';writeFileSync(resolve(out,name),text);const byteMatches=verify?readFileSync(resolve(verify,name)).equals(Buffer.from(text)):null;if(verify)assert(byteMatches,name);return {name,sha256:sha(text),byteMatches};});console.log(JSON.stringify({runtime:'TypeScript/Bun',results,evidenceCount:r.plan.evidence_records.length,decisionCount:r.plan.decision_records.length,allDecisionsPending:r.plan.decision_records.every((d:Json)=>d.decisionStatus==='pending'),rawHARRead:false},null,2));
}
if(resolve(process.argv[1]??'')===fileURLToPath(import.meta.url))cli();
